"use client"

import { useState, useEffect } from "react"
import { EcommerceHeader } from "@/components/ecommerce-header"
import { HeroSection } from "@/components/hero-section"
import { CategoryNavigation } from "@/components/category-navigation"
import { ProductGrid } from "@/components/product-grid"
import { ProductModal } from "@/components/product-modal"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviewCount: number
  image: string
  category: string
  tags: string[]
  inStock: boolean
}

interface CartItem extends Product {
  quantity: number
  options: any
}

export default function Home() {
  const [darkMode, setDarkMode] = useState(false)
  const [cart, setCart] = useState<CartItem[]>([])
  const [selectedCategory, setSelectedCategory] = useState("전체")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isProductModalOpen, setIsProductModalOpen] = useState(false)

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem("k-shop-cart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }

    const savedDarkMode = localStorage.getItem("k-shop-dark-mode")
    if (savedDarkMode) {
      setDarkMode(JSON.parse(savedDarkMode))
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("k-shop-cart", JSON.stringify(cart))
  }, [cart])

  // Save dark mode preference
  useEffect(() => {
    localStorage.setItem("k-shop-dark-mode", JSON.stringify(darkMode))
    if (darkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [darkMode])

  const handleAddToCart = (product: Product, quantity = 1, options: any = {}) => {
    const existingItemIndex = cart.findIndex(
      (item) => item.id === product.id && JSON.stringify(item.options) === JSON.stringify(options),
    )

    if (existingItemIndex > -1) {
      const newCart = [...cart]
      newCart[existingItemIndex].quantity += quantity
      setCart(newCart)
    } else {
      setCart([...cart, { ...product, quantity, options }])
    }

    // Show success message (you could add a toast here)
    console.log("[v0] Added to cart:", product.name, "Quantity:", quantity, "Options:", options)
  }

  const handleSearch = (query: string, category: string) => {
    setSearchQuery(query)
    if (category !== "전체") {
      // Map Korean category names to English IDs
      const categoryMap: { [key: string]: string } = {
        전자제품: "electronics",
        패션: "fashion",
        "홈&리빙": "home",
        스포츠: "sports",
        도서: "books",
        뷰티: "beauty",
      }
      setSelectedCategory(categoryMap[category] || "전체")
    } else {
      setSelectedCategory("전체")
    }
  }

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId)
    setSearchQuery("")
  }

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product)
    setIsProductModalOpen(true)
  }

  const handleCartClick = () => {
    // You could implement a cart modal here
    console.log("[v0] Cart clicked, items:", cart.length)
    alert(`장바구니에 ${cart.length}개 상품이 있습니다.`)
  }

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0)

  return (
    <div className="min-h-screen bg-background font-noto-kr">
      <EcommerceHeader
        cartCount={cartCount}
        onCartClick={handleCartClick}
        onSearch={handleSearch}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />

      <main>
        <HeroSection />
        <CategoryNavigation onCategorySelect={handleCategorySelect} />
        <ProductGrid
          selectedCategory={selectedCategory}
          searchQuery={searchQuery}
          onAddToCart={handleAddToCart}
          onProductClick={handleProductClick}
        />
      </main>

      <ProductModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={() => {
          setIsProductModalOpen(false)
          setSelectedProduct(null)
        }}
        onAddToCart={handleAddToCart}
      />

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold text-foreground mb-4 font-pretendard">K-Shop</h3>
              <p className="text-sm text-muted-foreground font-noto-kr">최고의 상품을 합리적인 가격에 만나보세요.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 font-pretendard">고객 서비스</h4>
              <ul className="space-y-2 text-sm text-muted-foreground font-noto-kr">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    주문 조회
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    배송 안내
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    반품/교환
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    고객센터
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 font-pretendard">회사 정보</h4>
              <ul className="space-y-2 text-sm text-muted-foreground font-noto-kr">
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    회사 소개
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    채용 정보
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    이용약관
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-primary transition-colors">
                    개인정보처리방침
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 font-pretendard">연락처</h4>
              <ul className="space-y-2 text-sm text-muted-foreground font-noto-kr">
                <li>고객센터: 1588-0000</li>
                <li>이메일: help@k-shop.com</li>
                <li>운영시간: 09:00 - 18:00</li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center">
            <p className="text-sm text-muted-foreground font-noto-kr">© 2024 K-Shop. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
