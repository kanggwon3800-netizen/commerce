"use client"

interface Category {
  id: string
  name: string
  icon: string
}

const categories: Category[] = [
  { id: "electronics", name: "전자제품", icon: "/electronics-icon.png" },
  { id: "fashion", name: "패션", icon: "/fashion-icon.png" },
  { id: "home", name: "홈&리빙", icon: "/home-living-icon.jpg" },
  { id: "sports", name: "스포츠", icon: "/sports-icon.png" },
  { id: "books", name: "도서", icon: "/books-icon.png" },
  { id: "beauty", name: "뷰티", icon: "/beauty-icon.png" },
  { id: "food", name: "식품", icon: "/food-icon.png" },
  { id: "toys", name: "완구", icon: "/toys-icon.png" },
]

interface CategoryNavigationProps {
  onCategorySelect: (categoryId: string) => void
}

export function CategoryNavigation({ onCategorySelect }: CategoryNavigationProps) {
  return (
    <section className="py-12 bg-accent">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 font-pretendard text-accent-foreground">
          카테고리별 쇼핑
        </h2>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-4 md:gap-6">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategorySelect(category.id)}
              className="flex flex-col items-center p-4 rounded-full bg-white hover:bg-accent-foreground/5 transition-all duration-200 hover:scale-105 group"
            >
              <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-secondary/10 flex items-center justify-center mb-2 group-hover:bg-secondary/20 transition-colors">
                <img src={category.icon || "/placeholder.svg"} alt={category.name} className="w-6 h-6 md:w-8 md:h-8" />
              </div>
              <span className="text-xs md:text-sm font-medium text-accent-foreground font-noto-kr text-center">
                {category.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
