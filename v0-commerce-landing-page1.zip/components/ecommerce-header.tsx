"use client"

import { useState } from "react"
import { Search, ShoppingCart, Menu, X, ChevronDown, Sun, Moon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface EcommerceHeaderProps {
  cartCount: number
  onCartClick: () => void
  onSearch: (query: string, category: string) => void
  darkMode: boolean
  onToggleDarkMode: () => void
}

export function EcommerceHeader({
  cartCount,
  onCartClick,
  onSearch,
  darkMode,
  onToggleDarkMode,
}: EcommerceHeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("전체")

  const categories = ["전체", "전자제품", "패션", "홈&리빙", "스포츠", "도서", "뷰티"]

  const handleSearch = () => {
    onSearch(searchQuery, selectedCategory)
  }

  return (
    <header className="sticky top-0 z-50 bg-primary shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-primary-foreground font-pretendard">K-Shop</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr">
              소개
            </a>
            <a href="#" className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr">
              블로그
            </a>
            <a href="#" className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr">
              연락처
            </a>
          </nav>

          {/* Search Bar */}
          <div className="hidden lg:flex items-center space-x-2 flex-1 max-w-md mx-8">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="bg-primary-foreground text-primary border-none">
                  <span className="font-noto-kr">{selectedCategory}</span>
                  <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {categories.map((category) => (
                  <DropdownMenuItem
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className="font-noto-kr"
                  >
                    {category}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <div className="flex-1 relative">
              <Input
                type="text"
                placeholder="상품을 검색하세요..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                className="bg-primary-foreground border-none font-noto-kr"
              />
              <Button
                onClick={handleSearch}
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 bg-secondary hover:bg-secondary/90"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Right Side Icons */}
          <div className="flex items-center space-x-4">
            {/* Dark Mode Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleDarkMode}
              className="text-primary-foreground hover:bg-primary-foreground/10"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>

            {/* Cart */}
            <Button
              variant="ghost"
              size="sm"
              onClick={onCartClick}
              className="relative text-primary-foreground hover:bg-primary-foreground/10"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-secondary text-secondary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-primary-foreground hover:bg-primary-foreground/10"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-primary-foreground/20">
            <div className="flex flex-col space-y-4">
              {/* Mobile Search */}
              <div className="flex items-center space-x-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="bg-primary-foreground text-primary">
                      <span className="font-noto-kr">{selectedCategory}</span>
                      <ChevronDown className="ml-1 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {categories.map((category) => (
                      <DropdownMenuItem
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className="font-noto-kr"
                      >
                        {category}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <div className="flex-1 relative">
                  <Input
                    type="text"
                    placeholder="상품을 검색하세요..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                    className="bg-primary-foreground border-none font-noto-kr"
                  />
                  <Button
                    onClick={handleSearch}
                    size="sm"
                    className="absolute right-1 top-1/2 -translate-y-1/2 bg-secondary hover:bg-secondary/90"
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Mobile Navigation */}
              <nav className="flex flex-col space-y-2">
                <a
                  href="#"
                  className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr"
                >
                  소개
                </a>
                <a
                  href="#"
                  className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr"
                >
                  블로그
                </a>
                <a
                  href="#"
                  className="text-primary-foreground hover:text-accent-foreground transition-colors font-noto-kr"
                >
                  연락처
                </a>
              </nav>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
