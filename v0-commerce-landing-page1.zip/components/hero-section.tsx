import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative h-[500px] md:h-[600px] overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/modern-korean-shopping-lifestyle-hero-banner.jpg')",
        }}
      />

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/50" />

      {/* Content */}
      <div className="relative container mx-auto px-4 h-full flex items-center">
        <div className="max-w-2xl text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 font-pretendard text-balance">
            최고의 상품을
            <br />
            <span className="text-accent-foreground">특별한 가격</span>으로
          </h1>
          <p className="text-lg md:text-xl mb-8 text-white/90 font-noto-kr text-pretty">
            엄선된 브랜드와 최신 트렌드 상품을 만나보세요. 지금 바로 특별한 할인 혜택을 확인하세요.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-noto-kr">
              추천 상품 보기
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-secondary hover:bg-secondary/90 text-secondary-foreground border-secondary px-8 py-3 text-lg font-noto-kr"
            >
              전체 상품 보기
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
