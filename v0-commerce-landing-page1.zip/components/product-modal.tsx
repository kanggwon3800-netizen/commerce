"use client"

import { useState } from "react"
import { Star, ShoppingCart, Heart, ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviewCount: number
  image: string
  category: string
  tags: string[]
  inStock: boolean
}

interface ProductModalProps {
  product: Product | null
  isOpen: boolean
  onClose: () => void
  onAddToCart: (product: Product, quantity: number, options: any) => void
}

const relatedProducts = [
  {
    id: "r1",
    name: "관련 상품 1",
    price: 45000,
    image: "/related-product-1.png",
  },
  {
    id: "r2",
    name: "관련 상품 2",
    price: 67000,
    image: "/related-product-2.png",
  },
  {
    id: "r3",
    name: "관련 상품 3",
    price: 89000,
    image: "/related-product-3.png",
  },
]

export function ProductModal({ product, isOpen, onClose, onAddToCart }: ProductModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [selectedColor, setSelectedColor] = useState("블랙")
  const [selectedMemory, setSelectedMemory] = useState("128GB")
  const [isFavorite, setIsFavorite] = useState(false)

  if (!product) return null

  const images = [product.image, "/product-display-sleek.png", "/product-image-3.png"]

  const colors = ["블랙", "화이트", "블루", "레드"]
  const memoryOptions = ["64GB", "128GB", "256GB", "512GB"]

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ko-KR").format(price) + "원"
  }

  const handleAddToCart = () => {
    onAddToCart(product, quantity, {
      color: selectedColor,
      memory: selectedMemory,
    })
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">상품 상세 정보</DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative">
              <img
                src={images[currentImageIndex] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-96 object-cover rounded-lg"
              />
              <button
                onClick={() => setCurrentImageIndex(Math.max(0, currentImageIndex - 1))}
                disabled={currentImageIndex === 0}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full disabled:opacity-50"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() => setCurrentImageIndex(Math.min(images.length - 1, currentImageIndex + 1))}
                disabled={currentImageIndex === images.length - 1}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-white/80 rounded-full disabled:opacity-50"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            <div className="flex gap-2">
              {images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-20 h-20 rounded-lg overflow-hidden border-2 ${
                    currentImageIndex === index ? "border-primary" : "border-transparent"
                  }`}
                >
                  <img src={image || "/placeholder.svg"} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between mb-2">
                <h1 className="text-2xl font-bold font-pretendard">{product.name}</h1>
                <button onClick={() => setIsFavorite(!isFavorite)} className="p-2 hover:bg-gray-100 rounded-full">
                  <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-600"}`} />
                </button>
              </div>

              {product.tags.length > 0 && (
                <div className="flex gap-2 mb-3">
                  {product.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="bg-secondary text-secondary-foreground">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground font-noto-kr">
                  {product.rating} ({product.reviewCount}개 리뷰)
                </span>
              </div>

              <div className="flex items-center gap-3 mb-6">
                <span className="text-3xl font-bold text-primary font-noto-kr">{formatPrice(product.price)}</span>
                {product.originalPrice && (
                  <span className="text-lg text-muted-foreground line-through font-noto-kr">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
              </div>
            </div>

            {/* Options */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2 font-noto-kr">색상</label>
                <div className="flex gap-2">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 rounded-lg border font-noto-kr ${
                        selectedColor === color
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary"
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 font-noto-kr">메모리</label>
                <div className="flex gap-2">
                  {memoryOptions.map((memory) => (
                    <button
                      key={memory}
                      onClick={() => setSelectedMemory(memory)}
                      className={`px-4 py-2 rounded-lg border font-noto-kr ${
                        selectedMemory === memory
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary"
                      }`}
                    >
                      {memory}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 font-noto-kr">수량</label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 border rounded-lg hover:bg-gray-50"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="text-lg font-medium w-12 text-center font-noto-kr">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="p-2 border rounded-lg hover:bg-gray-50">
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Add to Cart Button */}
            <Button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 text-lg font-noto-kr"
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              {product.inStock ? `${formatPrice(product.price * quantity)} 장바구니 담기` : "품절"}
            </Button>
          </div>
        </div>

        {/* Related Products */}
        <div className="mt-8 pt-8 border-t">
          <h3 className="text-xl font-bold mb-4 font-pretendard">관련 상품</h3>
          <div className="grid grid-cols-3 gap-4">
            {relatedProducts.map((relatedProduct) => (
              <div key={relatedProduct.id} className="text-center">
                <img
                  src={relatedProduct.image || "/placeholder.svg"}
                  alt={relatedProduct.name}
                  className="w-full h-32 object-cover rounded-lg mb-2"
                />
                <h4 className="text-sm font-medium mb-1 font-noto-kr">{relatedProduct.name}</h4>
                <p className="text-sm text-primary font-bold font-noto-kr">{formatPrice(relatedProduct.price)}</p>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
