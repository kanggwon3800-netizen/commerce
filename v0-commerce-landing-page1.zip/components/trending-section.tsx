import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const trendingArticles = [
  {
    id: 1,
    title: "Hot Air Ballooning As An Alternative Means Of Travel",
    excerpt: "Elementum nulla turpis cursus. Integer liberos kusto euismod aene pretium faucibus...",
    category: "World",
    date: "April 7, 2023",
    image: "/colorful-hot-air-balloons-floating-in-blue-sky.jpg",
    categoryColor: "bg-blue-500",
  },
  {
    id: 2,
    title: "VPN Security & Its Role In The Future Of Data Encryption",
    excerpt: "Elementum nulla turpis cursus. Integer liberos kusto euismod aene pretium faucibus...",
    category: "Security",
    date: "April 7, 2023",
    image: "/cybersecurity-concept-with-lock-icon-on-smartphone.jpg",
    categoryColor: "bg-green-600",
  },
]

export function TrendingSection() {
  return (
    <section className="mb-12">
      <h2 className="text-3xl font-bold text-foreground mb-8">What's Trending</h2>
      <div className="grid md:grid-cols-2 gap-8">
        {trendingArticles.map((article) => (
          <Card
            key={article.id}
            className="group cursor-pointer overflow-hidden border-0 shadow-lg hover:shadow-xl transition-shadow duration-300"
          >
            <div className="relative">
              <img
                src={article.image || "/placeholder.svg"}
                alt={article.title}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <Badge
                className={`absolute top-4 left-4 ${article.categoryColor} text-white hover:${article.categoryColor}`}
              >
                {article.category}
              </Badge>
            </div>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                {article.title}
              </h3>
              <p className="text-muted-foreground mb-4 line-clamp-3">{article.excerpt}</p>
              <p className="text-sm text-muted-foreground">{article.date}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
