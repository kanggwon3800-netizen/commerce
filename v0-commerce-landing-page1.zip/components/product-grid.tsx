"use client"

import { useState } from "react"
import { Star, ShoppingCart, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  rating: number
  reviewCount: number
  image: string
  category: string
  tags: string[]
  inStock: boolean
}

const products: Product[] = [
  {
    id: "1",
    name: "갤럭시 스마트폰 최신형",
    price: 899000,
    originalPrice: 1200000,
    rating: 4.8,
    reviewCount: 1234,
    image: "/samsung-galaxy-smartphone.png",
    category: "electronics",
    tags: ["인기", "할인"],
    inStock: true,
  },
  {
    id: "2",
    name: "프리미엄 무선 이어폰",
    price: 199000,
    originalPrice: 250000,
    rating: 4.6,
    reviewCount: 856,
    image: "/premium-wireless-earbuds.jpg",
    category: "electronics",
    tags: ["신상품"],
    inStock: true,
  },
  {
    id: "3",
    name: "스타일리시 캐주얼 재킷",
    price: 89000,
    rating: 4.4,
    reviewCount: 432,
    image: "/stylish-casual-jacket.jpg",
    category: "fashion",
    tags: ["트렌드"],
    inStock: true,
  },
  {
    id: "4",
    name: "모던 LED 스탠드",
    price: 65000,
    originalPrice: 85000,
    rating: 4.7,
    reviewCount: 298,
    image: "/modern-led-desk-lamp.jpg",
    category: "home",
    tags: ["베스트"],
    inStock: true,
  },
  {
    id: "5",
    name: "프로 러닝화",
    price: 129000,
    rating: 4.5,
    reviewCount: 567,
    image: "/professional-running-shoes.png",
    category: "sports",
    tags: ["스포츠"],
    inStock: false,
  },
  {
    id: "6",
    name: "베스트셀러 소설 세트",
    price: 45000,
    originalPrice: 60000,
    rating: 4.9,
    reviewCount: 1876,
    image: "/bestseller-novel-book-set.jpg",
    category: "books",
    tags: ["베스트셀러"],
    inStock: true,
  },
  {
    id: "7",
    name: "프리미엄 스킨케어 세트",
    price: 159000,
    rating: 4.6,
    reviewCount: 743,
    image: "/premium-skincare-set.jpg",
    category: "beauty",
    tags: ["뷰티"],
    inStock: true,
  },
  {
    id: "8",
    name: "유기농 건강 간식",
    price: 25000,
    rating: 4.3,
    reviewCount: 189,
    image: "/organic-healthy-snacks.jpg",
    category: "food",
    tags: ["유기농"],
    inStock: true,
  },
]

interface ProductGridProps {
  selectedCategory: string
  searchQuery: string
  onAddToCart: (product: Product) => void
  onProductClick: (product: Product) => void
}

export function ProductGrid({ selectedCategory, searchQuery, onAddToCart, onProductClick }: ProductGridProps) {
  const [favorites, setFavorites] = useState<Set<string>>(new Set())

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === "전체" || product.category === selectedCategory
    const matchesSearch = searchQuery === "" || product.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const toggleFavorite = (productId: string) => {
    const newFavorites = new Set(favorites)
    if (newFavorites.has(productId)) {
      newFavorites.delete(productId)
    } else {
      newFavorites.add(productId)
    }
    setFavorites(newFavorites)
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ko-KR").format(price) + "원"
  }

  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold font-pretendard">
            {selectedCategory === "전체" ? "전체 상품" : `${selectedCategory} 상품`}
          </h2>
          <p className="text-muted-foreground font-noto-kr">{filteredProducts.length}개 상품</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-card rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 overflow-hidden group cursor-pointer"
              onClick={() => onProductClick(product)}
            >
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleFavorite(product.id)
                  }}
                  className="absolute top-3 right-3 p-2 bg-white/80 rounded-full hover:bg-white transition-colors"
                >
                  <Heart
                    className={`h-4 w-4 ${favorites.has(product.id) ? "fill-red-500 text-red-500" : "text-gray-600"}`}
                  />
                </button>
                {product.tags.length > 0 && (
                  <div className="absolute top-3 left-3 flex gap-1">
                    {product.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs bg-secondary text-secondary-foreground">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
                {!product.inStock && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="text-white font-bold font-noto-kr">품절</span>
                  </div>
                )}
              </div>

              <div className="p-4">
                <h3 className="font-semibold text-card-foreground mb-2 line-clamp-2 font-noto-kr">{product.name}</h3>

                <div className="flex items-center gap-1 mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground font-noto-kr">({product.reviewCount})</span>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <span className="text-lg font-bold text-card-foreground font-noto-kr">
                    {formatPrice(product.price)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through font-noto-kr">
                      {formatPrice(product.originalPrice)}
                    </span>
                  )}
                </div>

                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    onAddToCart(product)
                  }}
                  disabled={!product.inStock}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-noto-kr"
                >
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  {product.inStock ? "장바구니 담기" : "품절"}
                </Button>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg font-noto-kr">검색 결과가 없습니다.</p>
          </div>
        )}
      </div>
    </section>
  )
}
