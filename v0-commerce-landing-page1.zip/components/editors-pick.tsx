import { Badge } from "@/components/ui/badge"

const editorsPicks = [
  {
    id: 1,
    title: "Top 10 Destinations For Budget Travelers In 2023",
    tags: ["Budget", "Destination"],
    image: "/tropical-beach-with-clear-blue-water-and-palm-tree.jpg",
  },
  {
    id: 2,
    title: "Exploring The Global Trends In Politics & Their Impact",
    tags: ["Global", "Politics"],
    image: "/government-building-with-columns-and-dome-architec.jpg",
  },
  {
    id: 3,
    title: "10 Things To Know About Your Alaskan Malamute",
    tags: ["Emergency", "Help"],
    image: "/fluffy-alaskan-malamute-dog-in-winter-snow-setting.jpg",
  },
]

export function EditorsPick() {
  return (
    <section>
      <h2 className="text-3xl font-bold text-foreground mb-8">Editor's Pick</h2>
      <div className="space-y-6">
        {editorsPicks.map((article) => (
          <div key={article.id} className="flex gap-4 group cursor-pointer">
            <div className="flex-shrink-0">
              <img
                src={article.image || "/placeholder.svg"}
                alt={article.title}
                className="w-24 h-24 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                {article.title}
              </h3>
              <div className="flex flex-wrap gap-2">
                <span className="text-sm text-muted-foreground">Tags:</span>
                {article.tags.map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
